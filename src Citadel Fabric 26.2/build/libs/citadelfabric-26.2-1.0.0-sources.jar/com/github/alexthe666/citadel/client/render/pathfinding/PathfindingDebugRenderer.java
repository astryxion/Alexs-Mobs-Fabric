package com.github.alexthe666.citadel.client.render.pathfinding;

import com.github.alexthe666.citadel.Citadel;
import com.github.alexthe666.citadel.server.entity.pathfinding.raycoms.MNode;
import net.minecraft.network.chat.Component;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.OrderedSubmitNodeCollector;
import net.minecraft.client.renderer.RenderBuffers;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;

import java.util.ConcurrentModificationException;
import java.util.HashSet;
import java.util.Set;

public class PathfindingDebugRenderer {
    public static final RenderBuffers renderBuffers = new RenderBuffers(Runtime.getRuntime().availableProcessors());
    /**
     * Set of visited nodes.
     */
    public static Set<MNode> lastDebugNodesVisited = new HashSet<>();

    /**
     * Set of not visited nodes.
     */
    public static Set<MNode> lastDebugNodesNotVisited = new HashSet<>();

    /**
     * Set of nodes that belong to the chosen path.
     */
    public static Set<MNode> lastDebugNodesPath = new HashSet<>();

    /**
     * Render debugging information for the pathfinding system.
     *
     * @param ctx rendering context
     */
    public static void render(final WorldEventContext ctx) {
        try {
            for (final MNode n : lastDebugNodesVisited) {
                debugDrawNode(n, 0xffff0000, ctx);
            }

            for (final MNode n : lastDebugNodesNotVisited) {
                debugDrawNode(n, 0xff0000ff, ctx);
            }

            for (final MNode n : lastDebugNodesPath) {
                if (n.isReachedByWorker()) {
                    debugDrawNode(n, 0xffff6600, ctx);
                } else {
                    debugDrawNode(n, 0xff00ff00, ctx);
                }
            }
        } catch (final ConcurrentModificationException exc) {
            Citadel.LOGGER.catching(exc);
        }
    }

    private static void debugDrawNode(final MNode n, final int argbColor, final WorldEventContext ctx) {
        ctx.poseStack.pushPose();
        ctx.poseStack.translate(n.pos.getX() + 0.375d, n.pos.getY() + 0.375d, n.pos.getZ() + 0.375d);

        final Entity entity = Minecraft.getInstance().getCameraEntity();
        if (n.pos.closerThan(entity.blockPosition(), 5d)) {
            renderDebugText(n, ctx);
        }

        ctx.poseStack.scale(0.25F, 0.25F, 0.25F);

        WorldRenderMacros.renderBox(ctx.submitCollector, ctx.poseStack, BlockPos.ZERO, BlockPos.ZERO, argbColor);

        if (n.parent != null) {
            final Matrix4f lineMatrix = ctx.poseStack.last().pose();

            final float pdx = n.parent.pos.getX() - n.pos.getX() + 0.125f;
            final float pdy = n.parent.pos.getY() - n.pos.getY() + 0.125f;
            final float pdz = n.parent.pos.getZ() - n.pos.getZ() + 0.125f;

            ctx.submitCollector.submitCustomGeometry(ctx.poseStack, WorldRenderMacros.LINES, (pose, buffer) -> {
                buffer.addVertex(lineMatrix, 0.5f, 0.5f, 0.5f).setColor(0.75F, 0.75F, 0.75F, 1.0F);
                buffer.addVertex(lineMatrix, pdx / 0.25f, pdy / 0.25f, pdz / 0.25f).setColor(0.75F, 0.75F, 0.75F, 1.0F);
            });
        }

        ctx.poseStack.popPose();
    }

    private static void renderDebugText(@NotNull final MNode n, final WorldEventContext ctx) {
        final Font fontrenderer = Minecraft.getInstance().font;

        final String s1 = String.format("F: %.3f [%d]", n.getCost(), n.getCounterAdded());
        final String s2 = String.format("G: %.3f [%d]", n.getScore(), n.getCounterVisited());
        final int i = Math.max(fontrenderer.width(s1), fontrenderer.width(s2)) / 2;

        ctx.poseStack.pushPose();
        ctx.poseStack.translate(0.0F, 0.75F, 0.0F);

        ctx.poseStack.mulPose(Minecraft.getInstance().gameRenderer.mainCamera().rotation());
        ctx.poseStack.scale(-0.014F, -0.014F, 0.014F);
        ctx.poseStack.translate(0.0F, 18F, 0.0F);
        final Matrix4f mat = ctx.poseStack.last().pose();

        WorldRenderMacros.renderFillRectangle(ctx.submitCollector, ctx.poseStack, -i - 1, -5, 0, 2 * i + 2, 17, 0x7f000000);

        ctx.poseStack.translate(0.0F, -5F, -0.1F);
        ctx.submitCollector.submitText(ctx.poseStack, -fontrenderer.width(s1) / 2.0f, 1, Component.literal(s1).getVisualOrderText(), false, Font.DisplayMode.NORMAL, 0xFFFFFFFF, 0, 15728880, 0);
        ctx.poseStack.translate(0.0F, 8F, -0.1F);
        ctx.submitCollector.submitText(ctx.poseStack, -fontrenderer.width(s2) / 2.0f, 1, Component.literal(s2).getVisualOrderText(), false, Font.DisplayMode.NORMAL, 0xFFFFFFFF, 0, 15728880, 0);

        ctx.poseStack.popPose();
    }


}